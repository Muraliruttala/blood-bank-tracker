import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Navigation from "@/components/navigation";
import AuthModal from "@/components/auth-modal";
import { Droplets, Hospital, Users, TrendingUp, Database, Shield, Building, Smartphone, Lock } from "lucide-react";

export default function Home() {
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; type: 'login' | 'register' | 'admin-register' }>({
    isOpen: false,
    type: 'login'
  });

  const openAuthModal = (type: 'login' | 'register' | 'admin-register') => {
    setAuthModal({ isOpen: true, type });
  };

  const closeAuthModal = () => {
    setAuthModal({ isOpen: false, type: 'login' });
  };

  return (
    <>
      <Navigation onAuthClick={openAuthModal} />
      
      {/* Hero Section */}
      <section className="medical-gradient text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
                Connecting Blood Banks with Healthcare Providers
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                BloodBank Bridge is a comprehensive platform that streamlines blood inventory management, 
                connects healthcare facilities, and ensures life-saving blood products reach patients when needed most.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Button 
                  onClick={() => openAuthModal('register')}
                  className="bg-white text-medical-blue hover:bg-gray-50 px-8 py-4 text-lg"
                >
                  <Users className="mr-2 h-5 w-5" />
                  Get Started
                </Button>
                <Button 
                  onClick={() => openAuthModal('admin-register')}
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-medical-blue px-8 py-4 text-lg"
                >
                  <Shield className="mr-2 h-5 w-5" />
                  Admin Access
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white bg-opacity-10 rounded-2xl p-8 backdrop-blur-sm">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-white bg-opacity-20 border-0">
                    <CardContent className="p-6 text-center text-white">
                      <Hospital className="h-12 w-12 mx-auto mb-3" />
                      <h3 className="font-semibold mb-2">Hospitals</h3>
                      <p className="text-sm text-blue-100">Connect with blood banks</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white bg-opacity-20 border-0">
                    <CardContent className="p-6 text-center text-white">
                      <Droplets className="h-12 w-12 mx-auto mb-3" />
                      <h3 className="font-semibold mb-2">Blood Banks</h3>
                      <p className="text-sm text-blue-100">Manage inventory</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white bg-opacity-20 border-0">
                    <CardContent className="p-6 text-center text-white">
                      <Users className="h-12 w-12 mx-auto mb-3" />
                      <h3 className="font-semibold mb-2">Patients</h3>
                      <p className="text-sm text-blue-100">Receive timely care</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white bg-opacity-20 border-0">
                    <CardContent className="p-6 text-center text-white">
                      <TrendingUp className="h-12 w-12 mx-auto mb-3" />
                      <h3 className="font-semibold mb-2">Analytics</h3>
                      <p className="text-sm text-blue-100">Data-driven insights</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Comprehensive Blood Management Solution</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our platform provides the tools and insights needed to optimize blood inventory management and improve patient outcomes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-medical-blue rounded-lg flex items-center justify-center mb-6">
                  <Database className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Real-time Inventory</h3>
                <p className="text-gray-600">Track blood unit availability across multiple locations with live updates and automated alerts.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-medical-red rounded-lg flex items-center justify-center mb-6">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Role-based Access</h3>
                <p className="text-gray-600">Secure access controls ensure sensitive blood bank data is only available to authorized administrators.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-medical-success rounded-lg flex items-center justify-center mb-6">
                  <Hospital className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Hospital Integration</h3>
                <p className="text-gray-600">Filter and view blood bank information by hospital to streamline coordination and transfers.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-medical-warning rounded-lg flex items-center justify-center mb-6">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Analytics & Reports</h3>
                <p className="text-gray-600">Generate comprehensive reports and gain insights into blood usage patterns and inventory trends.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mb-6">
                  <Smartphone className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Mobile Responsive</h3>
                <p className="text-gray-600">Access critical information from any device with our fully responsive web application.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mb-6">
                  <Lock className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Secure Authentication</h3>
                <p className="text-gray-600">Enterprise-grade security with separate authentication flows for administrators and healthcare users.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 medical-gradient text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Blood Bank Management?</h2>
          <p className="text-xl mb-8 text-blue-100">
            Join healthcare facilities across the region in modernizing blood inventory management and saving more lives.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
            <Button 
              onClick={() => openAuthModal('register')}
              className="bg-white text-medical-blue hover:bg-gray-50 px-8 py-4 text-lg"
            >
              Start as Healthcare User
            </Button>
            <Button 
              onClick={() => openAuthModal('admin-register')}
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-medical-blue px-8 py-4 text-lg"
            >
              Register as Administrator
            </Button>
          </div>
        </div>
      </section>

      <AuthModal 
        isOpen={authModal.isOpen}
        type={authModal.type}
        onClose={closeAuthModal}
      />
    </>
  );
}
