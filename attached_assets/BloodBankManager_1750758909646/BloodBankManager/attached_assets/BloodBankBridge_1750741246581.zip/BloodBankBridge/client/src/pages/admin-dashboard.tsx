import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import { Building, Hospital, Droplets, AlertTriangle, Plus, Search, Filter, Edit, BarChart3, MapPin, Calendar } from "lucide-react";
import type { BloodBank } from "@shared/schema";
import { z } from "zod";

interface DashboardStats {
  totalBanks: number;
  activeHospitals: number;
  totalUnits: number;
  criticalStock: number;
}

const bloodBankSchema = z.object({
  name: z.string().min(1, "Blood bank name is required"),
  hospital: z.string().min(1, "Hospital name is required"),
  address: z.string().min(1, "Address is required"),
  aPositive: z.coerce.number().min(0, "Must be 0 or greater"),
  aNegative: z.coerce.number().min(0, "Must be 0 or greater"),
  bPositive: z.coerce.number().min(0, "Must be 0 or greater"),
  bNegative: z.coerce.number().min(0, "Must be 0 or greater"),
  oPositive: z.coerce.number().min(0, "Must be 0 or greater"),
  oNegative: z.coerce.number().min(0, "Must be 0 or greater"),
  abPositive: z.coerce.number().min(0, "Must be 0 or greater"),
  abNegative: z.coerce.number().min(0, "Must be 0 or greater"),
});

export default function AdminDashboard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedHospital, setSelectedHospital] = useState<string>("all");
  const [editingBloodBank, setEditingBloodBank] = useState<BloodBank | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const bloodBankForm = useForm({
    resolver: zodResolver(bloodBankSchema),
    defaultValues: {
      name: '',
      hospital: '',
      address: '',
      aPositive: 0,
      aNegative: 0,
      bPositive: 0,
      bNegative: 0,
      oPositive: 0,
      oNegative: 0,
      abPositive: 0,
      abNegative: 0,
    }
  });

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: bloodBanks = [], isLoading } = useQuery<BloodBank[]>({
    queryKey: ["/api/blood-banks", selectedHospital !== "all" ? selectedHospital : null],
  });

  const { data: bloodRequests = [] } = useQuery({
    queryKey: ["/api/blood-requests"],
  });

  const { data: donationSchedules = [] } = useQuery({
    queryKey: ["/api/donation-schedules"],
  });

  const createBloodBankMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/blood-banks", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-banks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      bloodBankForm.reset();
      toast({
        title: "Blood bank created",
        description: "Blood bank has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Creation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateBloodBankMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => apiRequest("PUT", `/api/blood-banks/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-banks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setEditingBloodBank(null);
      bloodBankForm.reset();
      toast({
        title: "Blood bank updated",
        description: "Blood bank has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const fulfillRequestMutation = useMutation({
    mutationFn: (id: number) => apiRequest("PUT", `/api/blood-requests/${id}/fulfill`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-requests"] });
      toast({
        title: "Request fulfilled",
        description: "Blood request has been marked as fulfilled successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Fulfillment failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getBloodTypeColor = (count: number) => {
    if (count >= 20) return "bg-green-100 text-green-800";
    if (count >= 10) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const filteredBloodBanks = bloodBanks.filter(bank =>
    bank.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bank.hospital.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bank.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const uniqueHospitals = Array.from(new Set(bloodBanks.map(bank => bank.hospital)));

  const onBloodBankSubmit = (data: any) => {
    if (editingBloodBank) {
      updateBloodBankMutation.mutate({ id: editingBloodBank.id, data });
    } else {
      createBloodBankMutation.mutate(data);
    }
  };

  const handleEdit = (bloodBank: BloodBank) => {
    setEditingBloodBank(bloodBank);
    bloodBankForm.reset({
      name: bloodBank.name,
      hospital: bloodBank.hospital,
      address: bloodBank.address,
      aPositive: bloodBank.aPositive,
      aNegative: bloodBank.aNegative,
      bPositive: bloodBank.bPositive,
      bNegative: bloodBank.bNegative,
      oPositive: bloodBank.oPositive,
      oNegative: bloodBank.oNegative,
      abPositive: bloodBank.abPositive,
      abNegative: bloodBank.abNegative,
    });
  };

  const cancelEdit = () => {
    setEditingBloodBank(null);
    bloodBankForm.reset();
  };

  return (
    <>
      <Navigation />
      
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white shadow-sm border-b border-gray-200 py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-2xl font-bold text-gray-900">Administrator Dashboard</h1>
            <p className="text-gray-600">Blood Bank Management System</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Blood Banks</p>
                    <p className="text-2xl font-bold text-gray-900">{stats?.totalBanks || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-medical-blue bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Building className="h-6 w-6 text-medical-blue" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Active Hospitals</p>
                    <p className="text-2xl font-bold text-gray-900">{stats?.activeHospitals || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-medical-success bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Hospital className="h-6 w-6 text-medical-success" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Units Available</p>
                    <p className="text-2xl font-bold text-gray-900">{stats?.totalUnits?.toLocaleString() || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-medical-red bg-opacity-10 rounded-lg flex items-center justify-center">
                    <Droplets className="h-6 w-6 text-medical-red" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Critical Stock</p>
                    <p className="text-2xl font-bold text-medical-warning">{stats?.criticalStock || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-medical-warning bg-opacity-10 rounded-lg flex items-center justify-center">
                    <AlertTriangle className="h-6 w-6 text-medical-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabbed Interface */}
          <Tabs defaultValue="blood-banks" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="blood-banks">Blood Banks</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="blood-requests">Blood Requests</TabsTrigger>
              <TabsTrigger value="donation-schedules">Donation Schedules</TabsTrigger>
              <TabsTrigger value="add-blood-bank">Add Blood Bank</TabsTrigger>
              <TabsTrigger value="inventory">Inventory</TabsTrigger>
            </TabsList>

            <TabsContent value="blood-banks" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Blood Bank Management</CardTitle>
                    <div className="flex items-center space-x-3">
                      <Select value={selectedHospital} onValueChange={setSelectedHospital}>
                        <SelectTrigger className="w-48">
                          <SelectValue placeholder="Filter by hospital" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Hospitals</SelectItem>
                          {uniqueHospitals.map(hospital => (
                            <SelectItem key={hospital} value={hospital}>{hospital}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <div className="relative">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder="Search blood banks..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="text-center py-8">Loading blood bank data...</div>
                  ) : filteredBloodBanks.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">No blood banks found</div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Blood Bank</TableHead>
                            <TableHead>Hospital</TableHead>
                            <TableHead>Address</TableHead>
                            <TableHead className="text-center">A+</TableHead>
                            <TableHead className="text-center">A-</TableHead>
                            <TableHead className="text-center">B+</TableHead>
                            <TableHead className="text-center">B-</TableHead>
                            <TableHead className="text-center">O+</TableHead>
                            <TableHead className="text-center">O-</TableHead>
                            <TableHead className="text-center">AB+</TableHead>
                            <TableHead className="text-center">AB-</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredBloodBanks.map((bank) => (
                            <TableRow key={bank.id} className="hover:bg-gray-50">
                              <TableCell>
                                <div>
                                  <div className="font-medium text-gray-900">{bank.name}</div>
                                  <div className="text-sm text-gray-500">ID: BB{bank.id.toString().padStart(3, '0')}</div>
                                </div>
                              </TableCell>
                              <TableCell className="text-gray-900">{bank.hospital}</TableCell>
                              <TableCell className="text-gray-900">{bank.address}</TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.aPositive)}>{bank.aPositive}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.aNegative)}>{bank.aNegative}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.bPositive)}>{bank.bPositive}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.bNegative)}>{bank.bNegative}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.oPositive)}>{bank.oPositive}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.oNegative)}>{bank.oNegative}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.abPositive)}>{bank.abPositive}</Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={getBloodTypeColor(bank.abNegative)}>{bank.abNegative}</Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="text-medical-blue hover:text-blue-700"
                                  onClick={() => handleEdit(bank)}
                                >
                                  <Edit className="h-4 w-4 mr-1" />
                                  Edit
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>

              {editingBloodBank && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      Edit Blood Bank: {editingBloodBank.name}
                      <Button variant="ghost" onClick={cancelEdit}>Cancel</Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={bloodBankForm.handleSubmit(onBloodBankSubmit)} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Blood Bank Name</Label>
                          <Input
                            id="name"
                            {...bloodBankForm.register("name")}
                          />
                          {bloodBankForm.formState.errors.name && (
                            <p className="text-sm text-red-600 mt-1">{bloodBankForm.formState.errors.name.message}</p>
                          )}
                        </div>

                        <div>
                          <Label htmlFor="hospital">Hospital</Label>
                          <Input
                            id="hospital"
                            {...bloodBankForm.register("hospital")}
                          />
                          {bloodBankForm.formState.errors.hospital && (
                            <p className="text-sm text-red-600 mt-1">{bloodBankForm.formState.errors.hospital.message}</p>
                          )}
                        </div>

                        <div className="md:col-span-2">
                          <Label htmlFor="address">Address</Label>
                          <Textarea
                            id="address"
                            {...bloodBankForm.register("address")}
                          />
                          {bloodBankForm.formState.errors.address && (
                            <p className="text-sm text-red-600 mt-1">{bloodBankForm.formState.errors.address.message}</p>
                          )}
                        </div>

                        <div>
                          <Label htmlFor="aPositive">A+ Units</Label>
                          <Input
                            id="aPositive"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("aPositive")}
                          />
                        </div>

                        <div>
                          <Label htmlFor="aNegative">A- Units</Label>
                          <Input
                            id="aNegative"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("aNegative")}
                          />
                        </div>

                        <div>
                          <Label htmlFor="bPositive">B+ Units</Label>
                          <Input
                            id="bPositive"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("bPositive")}
                          />
                        </div>

                        <div>
                          <Label htmlFor="bNegative">B- Units</Label>
                          <Input
                            id="bNegative"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("bNegative")}
                          />
                        </div>

                        <div>
                          <Label htmlFor="oPositive">O+ Units</Label>
                          <Input
                            id="oPositive"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("oPositive")}
                          />
                        </div>

                        <div>
                          <Label htmlFor="oNegative">O- Units</Label>
                          <Input
                            id="oNegative"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("oNegative")}
                          />
                        </div>

                        <div>
                          <Label htmlFor="abPositive">AB+ Units</Label>
                          <Input
                            id="abPositive"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("abPositive")}
                          />
                        </div>

                        <div>
                          <Label htmlFor="abNegative">AB- Units</Label>
                          <Input
                            id="abNegative"
                            type="number"
                            min="0"
                            {...bloodBankForm.register("abNegative")}
                          />
                        </div>
                      </div>

                      <Button 
                        type="submit" 
                        className="w-full bg-medical-blue hover:bg-blue-700"
                        disabled={updateBloodBankMutation.isPending}
                      >
                        {updateBloodBankMutation.isPending ? "Updating..." : "Update Blood Bank"}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="reports" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <BarChart3 className="h-5 w-5 text-medical-blue mr-2" />
                      Blood Requests Report
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span>Total Requests</span>
                        <span className="font-semibold">{(bloodRequests as any[]).length}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Critical Priority</span>
                        <span className="font-semibold text-red-600">
                          {(bloodRequests as any[]).filter((req: any) => req.priorityLevel === 'critical').length}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>High Priority</span>
                        <span className="font-semibold text-orange-600">
                          {(bloodRequests as any[]).filter((req: any) => req.priorityLevel === 'high').length}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Pending Requests</span>
                        <span className="font-semibold">
                          {(bloodRequests as any[]).filter((req: any) => req.status === 'pending').length}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calendar className="h-5 w-5 text-medical-blue mr-2" />
                      Donation Schedules Report
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span>Total Scheduled</span>
                        <span className="font-semibold">{(donationSchedules as any[]).length}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>This Week</span>
                        <span className="font-semibold">
                          {(donationSchedules as any[]).filter((schedule: any) => {
                            const scheduleDate = new Date(schedule.donationDate);
                            const now = new Date();
                            const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
                            return scheduleDate >= now && scheduleDate <= weekFromNow;
                          }).length}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Scheduled Status</span>
                        <span className="font-semibold text-green-600">
                          {(donationSchedules as any[]).filter((schedule: any) => schedule.status === 'scheduled').length}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="add-blood-bank" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="h-6 w-6 text-medical-blue mr-2" />
                    Add New Blood Bank
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={bloodBankForm.handleSubmit(onBloodBankSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Blood Bank Name</Label>
                        <Input
                          id="name"
                          placeholder="Central Blood Bank"
                          {...bloodBankForm.register("name")}
                        />
                        {bloodBankForm.formState.errors.name && (
                          <p className="text-sm text-red-600 mt-1">{bloodBankForm.formState.errors.name.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="hospital">Hospital</Label>
                        <Input
                          id="hospital"
                          placeholder="City General Hospital"
                          {...bloodBankForm.register("hospital")}
                        />
                        {bloodBankForm.formState.errors.hospital && (
                          <p className="text-sm text-red-600 mt-1">{bloodBankForm.formState.errors.hospital.message}</p>
                        )}
                      </div>

                      <div className="md:col-span-2">
                        <Label htmlFor="address">Address</Label>
                        <Textarea
                          id="address"
                          placeholder="123 Main Street, Downtown"
                          {...bloodBankForm.register("address")}
                        />
                        {bloodBankForm.formState.errors.address && (
                          <p className="text-sm text-red-600 mt-1">{bloodBankForm.formState.errors.address.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="aPositive">A+ Units</Label>
                        <Input
                          id="aPositive"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("aPositive")}
                        />
                      </div>

                      <div>
                        <Label htmlFor="aNegative">A- Units</Label>
                        <Input
                          id="aNegative"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("aNegative")}
                        />
                      </div>

                      <div>
                        <Label htmlFor="bPositive">B+ Units</Label>
                        <Input
                          id="bPositive"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("bPositive")}
                        />
                      </div>

                      <div>
                        <Label htmlFor="bNegative">B- Units</Label>
                        <Input
                          id="bNegative"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("bNegative")}
                        />
                      </div>

                      <div>
                        <Label htmlFor="oPositive">O+ Units</Label>
                        <Input
                          id="oPositive"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("oPositive")}
                        />
                      </div>

                      <div>
                        <Label htmlFor="oNegative">O- Units</Label>
                        <Input
                          id="oNegative"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("oNegative")}
                        />
                      </div>

                      <div>
                        <Label htmlFor="abPositive">AB+ Units</Label>
                        <Input
                          id="abPositive"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("abPositive")}
                        />
                      </div>

                      <div>
                        <Label htmlFor="abNegative">AB- Units</Label>
                        <Input
                          id="abNegative"
                          type="number"
                          min="0"
                          placeholder="0"
                          {...bloodBankForm.register("abNegative")}
                        />
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-medical-blue hover:bg-blue-700"
                      disabled={createBloodBankMutation.isPending}
                    >
                      {createBloodBankMutation.isPending ? "Creating..." : "Create Blood Bank"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="blood-requests" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Droplets className="h-6 w-6 text-medical-red mr-2" />
                    Blood Request Management
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {bloodRequests.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">No blood requests found</div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Request ID</TableHead>
                            <TableHead>Patient Name</TableHead>
                            <TableHead>Blood Type</TableHead>
                            <TableHead>Units</TableHead>
                            <TableHead>Hospital</TableHead>
                            <TableHead>Priority</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {(bloodRequests as any[]).map((request: any) => (
                            <TableRow key={request.id} className="hover:bg-gray-50">
                              <TableCell className="font-medium">BR{request.id.toString().padStart(3, '0')}</TableCell>
                              <TableCell>{request.name}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{request.bloodType}</Badge>
                              </TableCell>
                              <TableCell>{request.units}</TableCell>
                              <TableCell>{request.hospital}</TableCell>
                              <TableCell>
                                <Badge className={
                                  request.priorityLevel === 'critical' ? 'bg-red-100 text-red-800' :
                                  request.priorityLevel === 'high' ? 'bg-orange-100 text-orange-800' :
                                  request.priorityLevel === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-gray-100 text-gray-800'
                                }>
                                  {request.priorityLevel}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge className={
                                  request.status === 'fulfilled' ? 'bg-green-100 text-green-800' :
                                  request.status === 'pending' ? 'bg-blue-100 text-blue-800' :
                                  'bg-gray-100 text-gray-800'
                                }>
                                  {request.status}
                                </Badge>
                              </TableCell>
                              <TableCell>{new Date(request.createdAt).toLocaleDateString()}</TableCell>
                              <TableCell className="text-right">
                                {request.status === 'pending' && (
                                  <Button 
                                    size="sm" 
                                    className="bg-green-600 hover:bg-green-700"
                                    onClick={() => fulfillRequestMutation.mutate(request.id)}
                                    disabled={fulfillRequestMutation.isPending}
                                  >
                                    {fulfillRequestMutation.isPending ? "Fulfilling..." : "Fulfill"}
                                  </Button>
                                )}
                                {request.status === 'fulfilled' && (
                                  <span className="text-sm text-green-600">Completed</span>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="donation-schedules" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="h-6 w-6 text-medical-blue mr-2" />
                    Donation Schedule Management
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {donationSchedules.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">No donation schedules found</div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Schedule ID</TableHead>
                            <TableHead>Donor Name</TableHead>
                            <TableHead>Blood Type</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Time</TableHead>
                            <TableHead>Contact</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Created</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {(donationSchedules as any[]).map((schedule: any) => (
                            <TableRow key={schedule.id} className="hover:bg-gray-50">
                              <TableCell className="font-medium">DS{schedule.id.toString().padStart(3, '0')}</TableCell>
                              <TableCell>{schedule.donorName}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{schedule.bloodType}</Badge>
                              </TableCell>
                              <TableCell>{new Date(schedule.donationDate).toLocaleDateString()}</TableCell>
                              <TableCell>{schedule.donationTime}</TableCell>
                              <TableCell>{schedule.contact}</TableCell>
                              <TableCell>
                                <Badge className={
                                  schedule.status === 'completed' ? 'bg-green-100 text-green-800' :
                                  schedule.status === 'scheduled' ? 'bg-blue-100 text-blue-800' :
                                  schedule.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                                  'bg-gray-100 text-gray-800'
                                }>
                                  {schedule.status}
                                </Badge>
                              </TableCell>
                              <TableCell>{new Date(schedule.createdAt).toLocaleDateString()}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="inventory" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Droplets className="h-6 w-6 text-medical-red mr-2" />
                    Blood Inventory Management
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <Select value={selectedHospital} onValueChange={setSelectedHospital}>
                        <SelectTrigger className="w-48">
                          <SelectValue placeholder="Filter by hospital" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Hospitals</SelectItem>
                          {uniqueHospitals.map(hospital => (
                            <SelectItem key={hospital} value={hospital}>{hospital}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <div className="relative">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder="Search inventory..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                    </div>

                    {isLoading ? (
                      <div className="text-center py-8">Loading inventory data...</div>
                    ) : filteredBloodBanks.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">No inventory found</div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Blood Bank</TableHead>
                              <TableHead>Hospital</TableHead>
                              <TableHead>Location</TableHead>
                              <TableHead className="text-center">A+</TableHead>
                              <TableHead className="text-center">A-</TableHead>
                              <TableHead className="text-center">B+</TableHead>
                              <TableHead className="text-center">B-</TableHead>
                              <TableHead className="text-center">O+</TableHead>
                              <TableHead className="text-center">O-</TableHead>
                              <TableHead className="text-center">AB+</TableHead>
                              <TableHead className="text-center">AB-</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredBloodBanks.map((bank) => (
                              <TableRow key={bank.id} className="hover:bg-gray-50">
                                <TableCell>
                                  <div>
                                    <div className="font-medium text-gray-900">{bank.name}</div>
                                    <div className="text-sm text-gray-500">ID: BB{bank.id.toString().padStart(3, '0')}</div>
                                  </div>
                                </TableCell>
                                <TableCell className="text-gray-900">{bank.hospital}</TableCell>
                                <TableCell>
                                  <div className="flex items-center">
                                    <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                                    <span className="text-sm text-gray-600">{bank.address}</span>
                                  </div>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.aPositive)}>{bank.aPositive}</Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.aNegative)}>{bank.aNegative}</Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.bPositive)}>{bank.bPositive}</Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.bNegative)}>{bank.bNegative}</Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.oPositive)}>{bank.oPositive}</Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.oNegative)}>{bank.oNegative}</Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.abPositive)}>{bank.abPositive}</Badge>
                                </TableCell>
                                <TableCell className="text-center">
                                  <Badge className={getBloodTypeColor(bank.abNegative)}>{bank.abNegative}</Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-medical-blue hover:text-blue-700"
                                    onClick={() => handleEdit(bank)}
                                  >
                                    <Edit className="h-4 w-4 mr-1" />
                                    Edit
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}
