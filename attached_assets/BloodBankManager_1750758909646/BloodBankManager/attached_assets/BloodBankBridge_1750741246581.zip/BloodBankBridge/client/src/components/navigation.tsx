import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Droplets, ChevronDown, LogOut } from "lucide-react";

interface NavigationProps {
  onAuthClick?: (type: 'login' | 'register' | 'admin-register') => void;
}

export default function Navigation({ onAuthClick }: NavigationProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const logoutMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/auth/logout"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account.",
      });
    },
    onError: () => {
      toast({
        title: "Logout failed",
        description: "There was an error logging out. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-medical-blue rounded-lg flex items-center justify-center">
              <Droplets className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-medical-blue">BloodBank Bridge</h1>
              <p className="text-xs text-gray-500">Healthcare Management System</p>
            </div>
          </div>
          
          {user && (
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-600 hover:text-medical-blue font-medium">Dashboard</a>
              {user.type === 'admin' && (
                <a href="#" className="text-gray-600 hover:text-medical-blue font-medium">Blood Banks</a>
              )}
              <a href="#" className="text-gray-600 hover:text-medical-blue font-medium">Reports</a>
            </nav>
          )}

          <div className="flex items-center space-x-4">
            {!user ? (
              <div className="space-x-3">
                <Button 
                  variant="ghost" 
                  onClick={() => onAuthClick?.('login')}
                  className="text-medical-blue font-medium hover:text-blue-700"
                >
                  Sign In
                </Button>
                <Button 
                  onClick={() => onAuthClick?.('register')}
                  className="bg-medical-blue text-white hover:bg-blue-700 font-medium"
                >
                  Get Started
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-gray-700">
                  <div className="w-8 h-8 bg-medical-blue rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium">
                      {user.name?.charAt(0)?.toUpperCase() || 'U'}
                    </span>
                  </div>
                  <span className="font-medium">{user.name}</span>
                  <span className="text-xs text-gray-500">
                    ({user.type === 'admin' ? 'Administrator' : 'Healthcare User'})
                  </span>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                  className="text-gray-600 hover:text-red-600"
                >
                  <LogOut className="h-4 w-4 mr-1" />
                  {logoutMutation.isPending ? "Logging out..." : "Logout"}
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
