import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Shield, AlertTriangle, X } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

interface AuthModalProps {
  isOpen: boolean;
  type: 'login' | 'register' | 'admin-register';
  onClose: () => void;
}

const adminLoginSchema = z.object({
  adminId: z.string().min(1, "Admin ID is required"),
  password: z.string().min(1, "Password is required"),
});

const userLoginSchema = z.object({
  email: z.string().email("Valid email is required"),
  password: z.string().min(1, "Password is required"),
});

const userRegisterSchema = z.object({
  name: z.string().min(1, "Full name is required"),
  email: z.string().email("Valid email is required"),
  mobileNumber: z.string().min(10, "Valid mobile number is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

const adminRegisterSchema = z.object({
  adminId: z.string().min(1, "Administrator ID is required"),
  name: z.string().min(1, "Full name is required"),
  organization: z.string().min(1, "Blood Bank Organization is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function AuthModal({ isOpen, type, onClose }: AuthModalProps) {
  const [loginType, setLoginType] = useState<'user' | 'admin'>('user');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const loginForm = useForm({
    resolver: zodResolver(loginType === 'admin' ? adminLoginSchema : userLoginSchema),
    defaultValues: loginType === 'admin' 
      ? { adminId: '', password: '' }
      : { email: '', password: '' }
  });

  const userRegisterForm = useForm({
    resolver: zodResolver(userRegisterSchema),
    defaultValues: { name: '', email: '', mobileNumber: '', password: '', confirmPassword: '' }
  });

  const adminRegisterForm = useForm({
    resolver: zodResolver(adminRegisterSchema),
    defaultValues: { adminId: '', name: '', organization: '', password: '', confirmPassword: '' }
  });

  const loginMutation = useMutation({
    mutationFn: (data: any) => {
      const endpoint = loginType === 'admin' ? '/api/auth/login/admin' : '/api/auth/login/user';
      return apiRequest("POST", endpoint, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Login successful",
        description: "Welcome back!",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const userRegisterMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/auth/register/user", data),
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "Your healthcare user account has been created successfully!",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const adminRegisterMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/auth/register/admin", data),
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "Your administrator account has been created successfully!",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onLoginSubmit = (data: any) => {
    loginMutation.mutate(data);
  };

  const onUserRegisterSubmit = (data: any) => {
    const { confirmPassword, ...submitData } = data;
    userRegisterMutation.mutate(submitData);
  };

  const onAdminRegisterSubmit = (data: any) => {
    const { confirmPassword, ...submitData } = data;
    adminRegisterMutation.mutate(submitData);
  };

  const getTitle = () => {
    switch (type) {
      case 'login': return 'Sign In';
      case 'register': return 'Register - Healthcare User';
      case 'admin-register': return 'Register - Administrator';
      default: return 'Authentication';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            {getTitle()}
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        {type === 'login' && (
          <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
            <div>
              <Label className="text-sm font-medium text-gray-700 mb-2">Login Type</Label>
              <RadioGroup value={loginType} onValueChange={(value: 'user' | 'admin') => setLoginType(value)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="user" id="user" />
                  <Label htmlFor="user">Healthcare User</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="admin" id="admin" />
                  <Label htmlFor="admin">Administrator</Label>
                </div>
              </RadioGroup>
            </div>

            {loginType === 'user' ? (
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="user@hospital.com"
                  {...loginForm.register("email")}
                />
                {loginForm.formState.errors.email && (
                  <p className="text-sm text-red-600 mt-1">{loginForm.formState.errors.email.message}</p>
                )}
              </div>
            ) : (
              <div>
                <Label htmlFor="adminId">Administrator ID</Label>
                <Input
                  id="adminId"
                  placeholder="Admin ID"
                  {...loginForm.register("adminId")}
                />
                {loginForm.formState.errors.adminId && (
                  <p className="text-sm text-red-600 mt-1">{loginForm.formState.errors.adminId.message}</p>
                )}
              </div>
            )}

            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                {...loginForm.register("password")}
              />
              {loginForm.formState.errors.password && (
                <p className="text-sm text-red-600 mt-1">{loginForm.formState.errors.password.message}</p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full bg-medical-blue hover:bg-blue-700"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "Signing in..." : "Sign In"}
            </Button>

            <div className="text-center">
              <p className="text-sm text-gray-600">
                Don't have an account?{" "}
                <Button variant="link" className="p-0 text-medical-blue" onClick={() => window.location.reload()}>
                  Register here
                </Button>
              </p>
            </div>
          </form>
        )}

        {type === 'register' && (
          <form onSubmit={userRegisterForm.handleSubmit(onUserRegisterSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                placeholder="Dr. Jane Smith"
                {...userRegisterForm.register("name")}
              />
              {userRegisterForm.formState.errors.name && (
                <p className="text-sm text-red-600 mt-1">{userRegisterForm.formState.errors.name.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="jane.smith@hospital.com"
                {...userRegisterForm.register("email")}
              />
              {userRegisterForm.formState.errors.email && (
                <p className="text-sm text-red-600 mt-1">{userRegisterForm.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="mobileNumber">Mobile Number</Label>
              <Input
                id="mobileNumber"
                placeholder="+1 (555) 123-4567"
                {...userRegisterForm.register("mobileNumber")}
              />
              {userRegisterForm.formState.errors.mobileNumber && (
                <p className="text-sm text-red-600 mt-1">{userRegisterForm.formState.errors.mobileNumber.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Create a secure password"
                {...userRegisterForm.register("password")}
              />
              {userRegisterForm.formState.errors.password && (
                <p className="text-sm text-red-600 mt-1">{userRegisterForm.formState.errors.password.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Confirm your password"
                {...userRegisterForm.register("confirmPassword")}
              />
              {userRegisterForm.formState.errors.confirmPassword && (
                <p className="text-sm text-red-600 mt-1">{userRegisterForm.formState.errors.confirmPassword.message}</p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full bg-medical-blue hover:bg-blue-700"
              disabled={userRegisterMutation.isPending}
            >
              {userRegisterMutation.isPending ? "Registering..." : "Register as Healthcare User"}
            </Button>
          </form>
        )}

        {type === 'admin-register' && (
          <form onSubmit={adminRegisterForm.handleSubmit(onAdminRegisterSubmit)} className="space-y-4">
            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="p-4">
                <div className="flex items-center">
                  <Shield className="h-5 w-5 text-yellow-600 mr-2" />
                  <p className="text-sm text-yellow-800">Administrator registration requires manual ID assignment.</p>
                </div>
              </CardContent>
            </Card>

            <div>
              <Label htmlFor="adminId">Administrator ID</Label>
              <Input
                id="adminId"
                placeholder="Enter your assigned Admin ID"
                {...adminRegisterForm.register("adminId")}
              />
              {adminRegisterForm.formState.errors.adminId && (
                <p className="text-sm text-red-600 mt-1">{adminRegisterForm.formState.errors.adminId.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                placeholder="Administrator Name"
                {...adminRegisterForm.register("name")}
              />
              {adminRegisterForm.formState.errors.name && (
                <p className="text-sm text-red-600 mt-1">{adminRegisterForm.formState.errors.name.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="organization">Blood Bank Organization</Label>
              <Input
                id="organization"
                placeholder="Regional Blood Center"
                {...adminRegisterForm.register("organization")}
              />
              {adminRegisterForm.formState.errors.organization && (
                <p className="text-sm text-red-600 mt-1">{adminRegisterForm.formState.errors.organization.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Create a secure password"
                {...adminRegisterForm.register("password")}
              />
              {adminRegisterForm.formState.errors.password && (
                <p className="text-sm text-red-600 mt-1">{adminRegisterForm.formState.errors.password.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Confirm your password"
                {...adminRegisterForm.register("confirmPassword")}
              />
              {adminRegisterForm.formState.errors.confirmPassword && (
                <p className="text-sm text-red-600 mt-1">{adminRegisterForm.formState.errors.confirmPassword.message}</p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full bg-medical-red hover:bg-red-700"
              disabled={adminRegisterMutation.isPending}
            >
              {adminRegisterMutation.isPending ? "Registering..." : "Register as Administrator"}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
