import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import { CheckCircle, Hospital, Calendar, Info, Droplets, Clock, User, Phone } from "lucide-react";
import { z } from "zod";

const bloodRequestSchema = z.object({
  name: z.string().min(1, "Name is required"),
  bloodType: z.enum(["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"], {
    required_error: "Blood type is required",
  }),
  units: z.coerce.number().min(1, "At least 1 unit is required").max(10, "Maximum 10 units allowed"),
  hospital: z.string().min(1, "Hospital is required"),
  priorityLevel: z.enum(["low", "medium", "high", "critical"], {
    required_error: "Priority level is required",
  }),
});

const donationScheduleSchema = z.object({
  donorName: z.string().min(1, "Donor name is required"),
  bloodType: z.enum(["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"], {
    required_error: "Blood type is required",
  }),
  donationDate: z.string().min(1, "Donation date is required"),
  donationTime: z.string().min(1, "Donation time is required"),
  contact: z.string().min(10, "Valid contact number is required"),
});

export default function UserDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const bloodRequestForm = useForm({
    resolver: zodResolver(bloodRequestSchema),
    defaultValues: { name: '', bloodType: '', units: 1, hospital: '', priorityLevel: '' }
  });

  const donationForm = useForm({
    resolver: zodResolver(donationScheduleSchema),
    defaultValues: { donorName: '', bloodType: '', donationDate: '', donationTime: '', contact: '' }
  });

  const { data: bloodRequests = [] } = useQuery({
    queryKey: ["/api/blood-requests"],
    enabled: !!user,
  });

  const { data: donationSchedules = [] } = useQuery({
    queryKey: ["/api/donation-schedules"],
    enabled: !!user,
  });

  const createBloodRequestMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/blood-requests", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blood-requests"] });
      bloodRequestForm.reset();
      toast({
        title: "Blood request submitted",
        description: "Your blood request has been submitted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Request failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createDonationMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/donation-schedules", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/donation-schedules"] });
      donationForm.reset();
      toast({
        title: "Donation scheduled",
        description: "Your donation has been scheduled successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Scheduling failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onBloodRequestSubmit = (data: any) => {
    createBloodRequestMutation.mutate(data);
  };

  const onDonationSubmit = (data: any) => {
    createDonationMutation.mutate(data);
  };

  return (
    <>
      <Navigation />
      
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Healthcare User Dashboard</h1>
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-medical-blue" />
                <span className="font-medium">{user?.name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-gray-500" />
                <span className="text-gray-600">{(user as any)?.mobileNumber}</span>
              </div>
            </div>
          </div>

          <Tabs defaultValue="request" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="request">Quick Blood Request</TabsTrigger>
              <TabsTrigger value="donation">Schedule Donation</TabsTrigger>
              <TabsTrigger value="history">Request History</TabsTrigger>
            </TabsList>

            <TabsContent value="request" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Droplets className="h-6 w-6 text-medical-red mr-2" />
                    Quick Blood Request
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={bloodRequestForm.handleSubmit(onBloodRequestSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Patient Name</Label>
                        <Input
                          id="name"
                          placeholder="John Doe"
                          {...bloodRequestForm.register("name")}
                        />
                        {bloodRequestForm.formState.errors.name && (
                          <p className="text-sm text-red-600 mt-1">{bloodRequestForm.formState.errors.name.message}</p>
                        )}
                      </div>
                      
                      <div>
                        <Label htmlFor="bloodType">Blood Type</Label>
                        <Select onValueChange={(value) => bloodRequestForm.setValue("bloodType", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select blood type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A+">A+</SelectItem>
                            <SelectItem value="A-">A-</SelectItem>
                            <SelectItem value="B+">B+</SelectItem>
                            <SelectItem value="B-">B-</SelectItem>
                            <SelectItem value="AB+">AB+</SelectItem>
                            <SelectItem value="AB-">AB-</SelectItem>
                            <SelectItem value="O+">O+</SelectItem>
                            <SelectItem value="O-">O-</SelectItem>
                          </SelectContent>
                        </Select>
                        {bloodRequestForm.formState.errors.bloodType && (
                          <p className="text-sm text-red-600 mt-1">{bloodRequestForm.formState.errors.bloodType.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="units">Units Required</Label>
                        <Input
                          id="units"
                          type="number"
                          min="1"
                          max="10"
                          placeholder="2"
                          {...bloodRequestForm.register("units")}
                        />
                        {bloodRequestForm.formState.errors.units && (
                          <p className="text-sm text-red-600 mt-1">{bloodRequestForm.formState.errors.units.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="hospital">Hospital</Label>
                        <Input
                          id="hospital"
                          placeholder="City General Hospital"
                          {...bloodRequestForm.register("hospital")}
                        />
                        {bloodRequestForm.formState.errors.hospital && (
                          <p className="text-sm text-red-600 mt-1">{bloodRequestForm.formState.errors.hospital.message}</p>
                        )}
                      </div>

                      <div className="md:col-span-2">
                        <Label htmlFor="priorityLevel">Priority Level</Label>
                        <Select onValueChange={(value) => bloodRequestForm.setValue("priorityLevel", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select priority level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="critical">Critical</SelectItem>
                          </SelectContent>
                        </Select>
                        {bloodRequestForm.formState.errors.priorityLevel && (
                          <p className="text-sm text-red-600 mt-1">{bloodRequestForm.formState.errors.priorityLevel.message}</p>
                        )}
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-medical-red hover:bg-red-700"
                      disabled={createBloodRequestMutation.isPending}
                    >
                      {createBloodRequestMutation.isPending ? "Submitting..." : "Submit Blood Request"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="donation" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="h-6 w-6 text-medical-blue mr-2" />
                    Schedule Blood Donation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={donationForm.handleSubmit(onDonationSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="donorName">Donor Name</Label>
                        <Input
                          id="donorName"
                          placeholder="Jane Smith"
                          {...donationForm.register("donorName")}
                        />
                        {donationForm.formState.errors.donorName && (
                          <p className="text-sm text-red-600 mt-1">{donationForm.formState.errors.donorName.message}</p>
                        )}
                      </div>
                      
                      <div>
                        <Label htmlFor="bloodTypeDonation">Blood Type</Label>
                        <Select onValueChange={(value) => donationForm.setValue("bloodType", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select blood type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A+">A+</SelectItem>
                            <SelectItem value="A-">A-</SelectItem>
                            <SelectItem value="B+">B+</SelectItem>
                            <SelectItem value="B-">B-</SelectItem>
                            <SelectItem value="AB+">AB+</SelectItem>
                            <SelectItem value="AB-">AB-</SelectItem>
                            <SelectItem value="O+">O+</SelectItem>
                            <SelectItem value="O-">O-</SelectItem>
                          </SelectContent>
                        </Select>
                        {donationForm.formState.errors.bloodType && (
                          <p className="text-sm text-red-600 mt-1">{donationForm.formState.errors.bloodType.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="donationDate">Donation Date</Label>
                        <Input
                          id="donationDate"
                          type="date"
                          {...donationForm.register("donationDate")}
                        />
                        {donationForm.formState.errors.donationDate && (
                          <p className="text-sm text-red-600 mt-1">{donationForm.formState.errors.donationDate.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="donationTime">Donation Time</Label>
                        <Input
                          id="donationTime"
                          type="time"
                          {...donationForm.register("donationTime")}
                        />
                        {donationForm.formState.errors.donationTime && (
                          <p className="text-sm text-red-600 mt-1">{donationForm.formState.errors.donationTime.message}</p>
                        )}
                      </div>

                      <div className="md:col-span-2">
                        <Label htmlFor="contact">Contact Number</Label>
                        <Input
                          id="contact"
                          placeholder="+1 (555) 123-4567"
                          {...donationForm.register("contact")}
                        />
                        {donationForm.formState.errors.contact && (
                          <p className="text-sm text-red-600 mt-1">{donationForm.formState.errors.contact.message}</p>
                        )}
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-medical-blue hover:bg-blue-700"
                      disabled={createDonationMutation.isPending}
                    >
                      {createDonationMutation.isPending ? "Scheduling..." : "Schedule Donation"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Droplets className="h-5 w-5 text-medical-red mr-2" />
                      Blood Requests
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {bloodRequests.length === 0 ? (
                      <p className="text-gray-500 text-center py-4">No blood requests yet</p>
                    ) : (
                      <div className="space-y-3">
                        {bloodRequests.map((request: any) => (
                          <div key={request.id} className="border rounded-lg p-3">
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-medium">{request.name}</span>
                              <span className={`px-2 py-1 rounded text-xs ${
                                request.priorityLevel === 'critical' ? 'bg-red-100 text-red-800' :
                                request.priorityLevel === 'high' ? 'bg-orange-100 text-orange-800' :
                                request.priorityLevel === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-gray-100 text-gray-800'
                              }`}>
                                {request.priorityLevel}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600">
                              {request.bloodType} • {request.units} units • {request.hospital}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              {new Date(request.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Clock className="h-5 w-5 text-medical-blue mr-2" />
                      Scheduled Donations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {donationSchedules.length === 0 ? (
                      <p className="text-gray-500 text-center py-4">No scheduled donations yet</p>
                    ) : (
                      <div className="space-y-3">
                        {donationSchedules.map((schedule: any) => (
                          <div key={schedule.id} className="border rounded-lg p-3">
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-medium">{schedule.donorName}</span>
                              <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                                {schedule.status}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600">
                              {schedule.bloodType} • {new Date(schedule.donationDate).toLocaleDateString()} at {schedule.donationTime}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              Contact: {schedule.contact}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}
