import {
  users,
  administrators,
  healthcareUsers,
  bloodBanks,
  bloodRequests,
  donationSchedules,
  type User,
  type UpsertUser,
  type Administrator,
  type InsertAdministrator,
  type HealthcareUser,
  type InsertHealthcareUser,
  type BloodBank,
  type InsertBloodBank,
  type BloodRequest,
  type InsertBloodRequest,
  type DonationSchedule,
  type InsertDonationSchedule,
} from "@shared/schema";
import { db } from "./db";
import { eq, like } from "drizzle-orm";

export interface IStorage {
  // User operations for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Administrator operations
  getAdministratorByAdminId(adminId: string): Promise<Administrator | undefined>;
  createAdministrator(admin: InsertAdministrator): Promise<Administrator>;
  
  // Healthcare user operations
  getHealthcareUserByEmail(email: string): Promise<HealthcareUser | undefined>;
  createHealthcareUser(user: InsertHealthcareUser): Promise<HealthcareUser>;
  
  // Blood bank operations
  getAllBloodBanks(): Promise<BloodBank[]>;
  getBloodBanksByHospital(hospital: string): Promise<BloodBank[]>;
  createBloodBank(bloodBank: InsertBloodBank): Promise<BloodBank>;
  updateBloodBank(id: number, bloodBank: Partial<InsertBloodBank>): Promise<BloodBank>;
  deleteBloodBank(id: number): Promise<void>;
  
  // Blood request operations
  createBloodRequest(request: InsertBloodRequest): Promise<BloodRequest>;
  getBloodRequestsByUserId(userId: number): Promise<BloodRequest[]>;
  getAllBloodRequests(): Promise<BloodRequest[]>;
  updateBloodRequestStatus(id: number, status: string): Promise<BloodRequest>;
  
  // Donation schedule operations
  createDonationSchedule(schedule: InsertDonationSchedule): Promise<DonationSchedule>;
  getDonationSchedulesByUserId(userId: number): Promise<DonationSchedule[]>;
  getAllDonationSchedules(): Promise<DonationSchedule[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Administrator operations
  async getAdministratorByAdminId(adminId: string): Promise<Administrator | undefined> {
    const [admin] = await db.select().from(administrators).where(eq(administrators.adminId, adminId));
    return admin;
  }

  async createAdministrator(admin: InsertAdministrator): Promise<Administrator> {
    const [newAdmin] = await db.insert(administrators).values(admin).returning();
    return newAdmin;
  }

  // Healthcare user operations
  async getHealthcareUserByEmail(email: string): Promise<HealthcareUser | undefined> {
    const [user] = await db.select().from(healthcareUsers).where(eq(healthcareUsers.email, email));
    return user;
  }

  async createHealthcareUser(user: InsertHealthcareUser): Promise<HealthcareUser> {
    const [newUser] = await db.insert(healthcareUsers).values(user).returning();
    return newUser;
  }

  // Blood bank operations
  async getAllBloodBanks(): Promise<BloodBank[]> {
    return await db.select().from(bloodBanks);
  }

  async getBloodBanksByHospital(hospital: string): Promise<BloodBank[]> {
    return await db.select().from(bloodBanks).where(like(bloodBanks.hospital, `%${hospital}%`));
  }

  async createBloodBank(bloodBank: InsertBloodBank): Promise<BloodBank> {
    const [newBloodBank] = await db.insert(bloodBanks).values(bloodBank).returning();
    return newBloodBank;
  }

  async updateBloodBank(id: number, bloodBank: Partial<InsertBloodBank>): Promise<BloodBank> {
    const [updatedBloodBank] = await db
      .update(bloodBanks)
      .set({ ...bloodBank, updatedAt: new Date() })
      .where(eq(bloodBanks.id, id))
      .returning();
    return updatedBloodBank;
  }

  async deleteBloodBank(id: number): Promise<void> {
    await db.delete(bloodBanks).where(eq(bloodBanks.id, id));
  }

  // Blood request operations
  async createBloodRequest(request: InsertBloodRequest): Promise<BloodRequest> {
    const [newRequest] = await db.insert(bloodRequests).values(request).returning();
    return newRequest;
  }

  async getBloodRequestsByUserId(userId: number): Promise<BloodRequest[]> {
    return await db.select().from(bloodRequests).where(eq(bloodRequests.userId, userId));
  }

  async getAllBloodRequests(): Promise<BloodRequest[]> {
    return await db.select().from(bloodRequests);
  }

  async updateBloodRequestStatus(id: number, status: string): Promise<BloodRequest> {
    const [updatedRequest] = await db
      .update(bloodRequests)
      .set({ status })
      .where(eq(bloodRequests.id, id))
      .returning();
    return updatedRequest;
  }

  // Donation schedule operations
  async createDonationSchedule(schedule: InsertDonationSchedule): Promise<DonationSchedule> {
    const [newSchedule] = await db.insert(donationSchedules).values(schedule).returning();
    return newSchedule;
  }

  async getDonationSchedulesByUserId(userId: number): Promise<DonationSchedule[]> {
    return await db.select().from(donationSchedules).where(eq(donationSchedules.userId, userId));
  }

  async getAllDonationSchedules(): Promise<DonationSchedule[]> {
    return await db.select().from(donationSchedules);
  }
}

export const storage = new DatabaseStorage();
