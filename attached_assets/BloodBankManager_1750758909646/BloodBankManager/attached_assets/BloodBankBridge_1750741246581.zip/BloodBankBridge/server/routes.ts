import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import { insertAdministratorSchema, insertHealthcareUserSchema, insertBloodBankSchema, insertBloodRequestSchema, insertDonationScheduleSchema } from "@shared/schema";
import { z } from "zod";

// Login schemas
const adminLoginSchema = z.object({
  adminId: z.string().min(1, "Admin ID is required"),
  password: z.string().min(1, "Password is required"),
});

const userLoginSchema = z.object({
  email: z.string().email("Valid email is required"),
  password: z.string().min(1, "Password is required"),
});

// Session user interface
interface SessionUser {
  id: string;
  type: 'admin' | 'user';
  name: string;
  organization?: string;
  mobileNumber?: string;
}

// Auth middleware
const requireAuth = (req: any, res: any, next: any) => {
  if (!req.session?.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
};

const requireAdmin = (req: any, res: any, next: any) => {
  if (!req.session?.user || req.session.user.type !== 'admin') {
    return res.status(403).json({ message: "Admin access required" });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'blood-bank-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: false, // Set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Auth routes
  app.get('/api/auth/user', (req: any, res) => {
    if (!req.session?.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.session.user);
  });

  // Admin registration
  app.post('/api/auth/register/admin', async (req, res) => {
    try {
      const validatedData = insertAdministratorSchema.parse(req.body);
      
      // Check if admin ID already exists
      const existingAdmin = await storage.getAdministratorByAdminId(validatedData.adminId);
      if (existingAdmin) {
        return res.status(400).json({ message: "Administrator ID already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 12);
      
      const admin = await storage.createAdministrator({
        ...validatedData,
        password: hashedPassword,
      });

      res.status(201).json({ message: "Administrator registered successfully" });
    } catch (error) {
      console.error("Admin registration error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // User registration
  app.post('/api/auth/register/user', async (req, res) => {
    try {
      const validatedData = insertHealthcareUserSchema.parse(req.body);
      
      // Check if email already exists
      const existingUser = await storage.getHealthcareUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 12);
      
      const user = await storage.createHealthcareUser({
        ...validatedData,
        password: hashedPassword,
      });

      res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
      console.error("User registration error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Admin login
  app.post('/api/auth/login/admin', async (req, res) => {
    try {
      const { adminId, password } = adminLoginSchema.parse(req.body);
      
      const admin = await storage.getAdministratorByAdminId(adminId);
      if (!admin) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, admin.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set session
      (req as any).session.user = {
        id: admin.id.toString(),
        type: 'admin',
        name: admin.name,
        organization: admin.organization,
      } as SessionUser;

      res.json({ 
        message: "Login successful",
        user: {
          id: admin.id,
          type: 'admin',
          name: admin.name,
          organization: admin.organization,
        }
      });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(401).json({ message: "Login failed" });
    }
  });

  // User login
  app.post('/api/auth/login/user', async (req, res) => {
    try {
      const { email, password } = userLoginSchema.parse(req.body);
      
      const user = await storage.getHealthcareUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set session
      (req as any).session.user = {
        id: user.id.toString(),
        type: 'user',
        name: user.name,
        mobileNumber: user.mobileNumber,
      } as SessionUser;

      res.json({ 
        message: "Login successful",
        user: {
          id: user.id,
          type: 'user',
          name: user.name,
          mobileNumber: user.mobileNumber,
        }
      });
    } catch (error) {
      console.error("User login error:", error);
      res.status(401).json({ message: "Login failed" });
    }
  });

  // Logout
  app.post('/api/auth/logout', (req: any, res) => {
    req.session.destroy((err: any) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  // Blood bank routes (Admin only)
  app.get('/api/blood-banks', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { hospital } = req.query;
      let bloodBanks;
      
      if (hospital && typeof hospital === 'string') {
        bloodBanks = await storage.getBloodBanksByHospital(hospital);
      } else {
        bloodBanks = await storage.getAllBloodBanks();
      }
      
      res.json(bloodBanks);
    } catch (error) {
      console.error("Error fetching blood banks:", error);
      res.status(500).json({ message: "Failed to fetch blood banks" });
    }
  });

  app.post('/api/blood-banks', requireAuth, requireAdmin, async (req, res) => {
    try {
      const validatedData = insertBloodBankSchema.parse(req.body);
      const bloodBank = await storage.createBloodBank(validatedData);
      res.status(201).json(bloodBank);
    } catch (error) {
      console.error("Error creating blood bank:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create blood bank" });
    }
  });

  app.put('/api/blood-banks/:id', requireAuth, requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertBloodBankSchema.partial().parse(req.body);
      const bloodBank = await storage.updateBloodBank(id, validatedData);
      res.json(bloodBank);
    } catch (error) {
      console.error("Error updating blood bank:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update blood bank" });
    }
  });

  app.delete('/api/blood-banks/:id', requireAuth, requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteBloodBank(id);
      res.json({ message: "Blood bank deleted successfully" });
    } catch (error) {
      console.error("Error deleting blood bank:", error);
      res.status(500).json({ message: "Failed to delete blood bank" });
    }
  });

  // Dashboard stats (Admin only)
  app.get('/api/dashboard/stats', requireAuth, requireAdmin, async (req, res) => {
    try {
      const bloodBanks = await storage.getAllBloodBanks();
      
      const totalBanks = bloodBanks.length;
      const activeHospitals = new Set(bloodBanks.map(bb => bb.hospital)).size;
      const totalUnits = bloodBanks.reduce((sum, bb) => 
        sum + bb.aPositive + bb.aNegative + bb.bPositive + bb.bNegative + 
        bb.oPositive + bb.oNegative + bb.abPositive + bb.abNegative, 0
      );
      
      // Count blood banks with any blood type having less than 10 units
      const criticalStock = bloodBanks.filter(bb => 
        bb.aPositive < 10 || bb.aNegative < 10 || bb.bPositive < 10 || bb.bNegative < 10 ||
        bb.oPositive < 10 || bb.oNegative < 10 || bb.abPositive < 10 || bb.abNegative < 10
      ).length;

      res.json({
        totalBanks,
        activeHospitals,
        totalUnits,
        criticalStock,
      });
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Blood request routes (User only)
  app.post('/api/blood-requests', requireAuth, async (req, res) => {
    try {
      const userId = parseInt((req as any).session.user.id);
      const validatedData = insertBloodRequestSchema.parse({
        ...req.body,
        userId,
      });
      
      const request = await storage.createBloodRequest(validatedData);
      res.status(201).json(request);
    } catch (error) {
      console.error("Error creating blood request:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create blood request" });
    }
  });

  app.get('/api/blood-requests', requireAuth, async (req, res) => {
    try {
      const user = (req as any).session.user;
      let requests;
      
      if (user.type === 'admin') {
        requests = await storage.getAllBloodRequests();
      } else {
        const userId = parseInt(user.id);
        requests = await storage.getBloodRequestsByUserId(userId);
      }
      
      res.json(requests);
    } catch (error) {
      console.error("Error fetching blood requests:", error);
      res.status(500).json({ message: "Failed to fetch blood requests" });
    }
  });

  // Donation schedule routes (User only)
  app.post('/api/donation-schedules', requireAuth, async (req, res) => {
    try {
      const userId = parseInt((req as any).session.user.id);
      const scheduleData = {
        ...req.body,
        userId,
        donationDate: new Date(req.body.donationDate)
      };
      const validatedData = insertDonationScheduleSchema.parse(scheduleData);
      
      const schedule = await storage.createDonationSchedule(validatedData);
      res.status(201).json(schedule);
    } catch (error) {
      console.error("Error creating donation schedule:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create donation schedule" });
    }
  });

  app.get('/api/donation-schedules', requireAuth, async (req, res) => {
    try {
      const user = (req as any).session.user;
      let schedules;
      
      if (user.type === 'admin') {
        schedules = await storage.getAllDonationSchedules();
      } else {
        const userId = parseInt(user.id);
        schedules = await storage.getDonationSchedulesByUserId(userId);
      }
      
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching donation schedules:", error);
      res.status(500).json({ message: "Failed to fetch donation schedules" });
    }
  });

  // Admin blood request management
  app.put('/api/blood-requests/:id/fulfill', requireAdmin, async (req, res) => {
    try {
      const requestId = parseInt(req.params.id);
      const updatedRequest = await storage.updateBloodRequestStatus(requestId, 'fulfilled');
      res.json({ message: "Blood request fulfilled successfully", request: updatedRequest });
    } catch (error) {
      console.error("Error fulfilling blood request:", error);
      res.status(500).json({ message: "Failed to fulfill blood request" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
