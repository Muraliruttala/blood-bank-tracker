import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Blood bank administrators
export const administrators = pgTable("administrators", {
  id: serial("id").primaryKey(),
  adminId: varchar("admin_id").notNull().unique(),
  name: varchar("name").notNull(),
  organization: varchar("organization").notNull(),
  password: varchar("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Healthcare users
export const healthcareUsers = pgTable("healthcare_users", {
  id: serial("id").primaryKey(),
  email: varchar("email").notNull().unique(),
  name: varchar("name").notNull(),
  mobileNumber: varchar("mobile_number").notNull(),
  password: varchar("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Blood banks
export const bloodBanks = pgTable("blood_banks", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  hospital: varchar("hospital").notNull(),
  address: text("address").notNull(),
  aPositive: integer("a_positive").notNull().default(0),
  aNegative: integer("a_negative").notNull().default(0),
  bPositive: integer("b_positive").notNull().default(0),
  bNegative: integer("b_negative").notNull().default(0),
  oPositive: integer("o_positive").notNull().default(0),
  oNegative: integer("o_negative").notNull().default(0),
  abPositive: integer("ab_positive").notNull().default(0),
  abNegative: integer("ab_negative").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Blood requests
export const bloodRequests = pgTable("blood_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: varchar("name").notNull(),
  bloodType: varchar("blood_type").notNull(),
  units: integer("units").notNull(),
  hospital: varchar("hospital").notNull(),
  priorityLevel: varchar("priority_level").notNull(),
  status: varchar("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Donation schedules
export const donationSchedules = pgTable("donation_schedules", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  donorName: varchar("donor_name").notNull(),
  bloodType: varchar("blood_type").notNull(),
  donationDate: timestamp("donation_date").notNull(),
  donationTime: varchar("donation_time").notNull(),
  contact: varchar("contact").notNull(),
  status: varchar("status").notNull().default("scheduled"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const insertAdministratorSchema = createInsertSchema(administrators).omit({
  id: true,
  createdAt: true,
});

export const insertHealthcareUserSchema = createInsertSchema(healthcareUsers).omit({
  id: true,
  createdAt: true,
});

export const insertBloodBankSchema = createInsertSchema(bloodBanks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBloodRequestSchema = createInsertSchema(bloodRequests).omit({
  id: true,
  createdAt: true,
  status: true,
});

export const insertDonationScheduleSchema = createInsertSchema(donationSchedules).omit({
  id: true,
  createdAt: true,
  status: true,
});

export type InsertAdministrator = z.infer<typeof insertAdministratorSchema>;
export type Administrator = typeof administrators.$inferSelect;

export type InsertHealthcareUser = z.infer<typeof insertHealthcareUserSchema>;
export type HealthcareUser = typeof healthcareUsers.$inferSelect;

export type InsertBloodBank = z.infer<typeof insertBloodBankSchema>;
export type BloodBank = typeof bloodBanks.$inferSelect;

export type InsertBloodRequest = z.infer<typeof insertBloodRequestSchema>;
export type BloodRequest = typeof bloodRequests.$inferSelect;

export type InsertDonationSchedule = z.infer<typeof insertDonationScheduleSchema>;
export type DonationSchedule = typeof donationSchedules.$inferSelect;
